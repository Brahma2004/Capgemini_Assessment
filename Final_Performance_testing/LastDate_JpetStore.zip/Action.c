Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

/*Correlation comment - Do not change!  Original value='FISH' Name ='C_Product' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_Product",
		"RegExp=categories/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTTP", 
		LAST);

	lr_start_transaction("1_LaunchUrl");

	web_concurrent_start(NULL);

	web_url("logo-topbar.gif", 
		"URL=https://jpetstore.aspectran.com/images/logo-topbar.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t15.inf", 
		LAST);

	web_url("splash.gif", 
		"URL=https://jpetstore.aspectran.com/images/splash.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t16.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("1_LaunchUrl",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("2_Category");

	web_url("Fish",
		"URL=https://jpetstore.aspectran.com/categories/{C_Product}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/",
		"Snapshot=t17.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("2_Category",LR_AUTO);

	web_websocket_send("ID=2", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790836606237\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 2 received buffer WebSocketReceive0*/

	lr_think_time(6);

	lr_start_transaction("3_Product_Id");

/*Correlation comment - Do not change!  Original value='EST-1' Name ='p_itemid' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=p_itemid",
		"RegExp=items/(.*?)\">EST-1",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("FI-SW-01",
		"URL=https://jpetstore.aspectran.com/products/FI-SW-01",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/categories/{C_Product}",
		"Snapshot=t18.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("3_Product_Id",LR_AUTO);

	lr_think_time(13);

	lr_start_transaction("4_Item_Id");

	web_url("EST-1",
		"URL=https://jpetstore.aspectran.com/products/FI-SW-01/items/{p_itemid}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/FI-SW-01",
		"Snapshot=t19.inf",
		"Mode=HTTP",
		LAST);

	web_url("fish1.jpg",
		"URL=https://jpetstore.aspectran.com/images/fish1.jpg",
		"Resource=1",
		"RecContentType=image/jpeg",
		"Referer=https://jpetstore.aspectran.com/products/FI-SW-01/items/{p_itemid}",
		"Snapshot=t20.inf",
		LAST);

	lr_end_transaction("4_Item_Id",LR_AUTO);

	lr_start_transaction("5_Add_TO_Cart");

	web_url("Add to Cart",
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId={p_itemid}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/FI-SW-01/items/{p_itemid}",
		"Snapshot=t21.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("5_Add_TO_Cart",LR_AUTO);

	lr_start_transaction("6_CheckOut");

	web_url("Proceed to Checkout", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t22.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("6_CheckOut",LR_AUTO);

	lr_start_transaction("7_Login");

	web_submit_data("signon", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm?referer=/order/newOrderForm", 
		"Snapshot=t23.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=referer", "Value=/order/newOrderForm", ENDITEM, 
		"Name=username", "Value={username}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		LAST);

	web_url("banner_dogs.gif", 
		"URL=https://jpetstore.aspectran.com/images/banner_dogs.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t24.inf", 
		LAST);

	lr_end_transaction("7_Login",LR_AUTO);

	lr_think_time(12);

	lr_start_transaction("8_Continue");

	web_submit_data("newOrder", 
		"Action=https://jpetstore.aspectran.com/order/newOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t25.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentForm", "Value=true", ENDITEM, 
		"Name=billingForm", "Value=true", ENDITEM, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value=999999999999999", ENDITEM, 
		"Name=expiryDate", "Value=12/2019", ENDITEM, 
		"Name=billToFirstName", "Value=Test", ENDITEM, 
		"Name=billToLastName", "Value=User", ENDITEM, 
		"Name=billAddress1", "Value=123 Test St", ENDITEM, 
		"Name=billAddress2", "Value=123 Test St", ENDITEM, 
		"Name=billCity", "Value=Testville", ENDITEM, 
		"Name=billState", "Value=CA", ENDITEM, 
		"Name=billZip", "Value=10001", ENDITEM, 
		"Name=billCountry", "Value=US", ENDITEM, 
		LAST);

	lr_end_transaction("8_Continue",LR_AUTO);

	lr_start_transaction("9_Confirm");

	web_submit_data("submitOrder", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t26.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	lr_end_transaction("9_Confirm",LR_AUTO);

	return 0;
}